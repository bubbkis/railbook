class Member < ApplicationRecord
end
