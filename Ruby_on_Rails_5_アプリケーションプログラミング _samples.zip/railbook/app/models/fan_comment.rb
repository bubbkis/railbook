class FanComment < ApplicationRecord
end
