class Admin::BooksController < ApplicationController
end
