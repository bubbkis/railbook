{
  ja: {
    general: {
      greeting: {
        night: 'こんばんは。',
        weather: '%{name}さん、良いお天気ですね！'
      }
    }
  }
}
